// Τα ερωτήματα 2 έως 7 θα απαντηθούν στο αρχείο αυτό

const newGuess = document.querySelector("#new-guess");
const message = document.querySelector("#message");
const lowHigh = document.querySelector("#low-high");
const checkButton = document.querySelector("#check");
const restartButton = document.querySelector("#restart");
const root = document.querySelector(":root");
var styles = getComputedStyle(root);

// 2. να ορίσετε τους σχετικούς χειριστές συμβάντων

checkButton.addEventListener("click", checkGuess);
newGuess.addEventListener("keyup", checkKey);
restartButton.addEventListener("click", restart);
let previousGuesses = [];
let theGuess;
window.onload = newRandom();
window.onload = (() => {restartButton.style.display = "none";})();
newGuess.focus();

function newRandom(){
/* 3. συνάρτηση που βρίσκει ένα τυχαίο αριθμό μεταξύ 1 και 100
 και τον εκχωρεί στη μεταβλητή theGuess */
 theGuess = Math.floor(Math.random()*100) +1;
}

function checkKey(e){
/* 4. συνάρτηση που όταν ο χρήστης πατήσει <<enter>>
 να καλεί τη συνάρτηση που αποτελεί τον κεντρικό ελεγκτή του παιχνιδιού.
 */
    if (e.code === "Enter") {checkGuess();}
}

function checkGuess(){
/* 5. Να ορίσετε συνάρτηση checkGuess η οποία καλείται είτε όταν ο χρήστης πατήσει <<enter>>
στο πεδίο "new-guess" είτε όταν πατήσει το πλήκτρο "check", η οποία είναι ο κεντρικός ελεγκτής,
καλεί τη συνάρτηση processGuess (η οποία αποφαίνεται για την ορθότητα του αριθμού) και κάνει
τις κατάλληλες ενέργειες για να μην μπορεί να εισάγει ο χρήστης νέο αριθμό ή να ανασταλεί η
λειτουργία του <<enter>>, εμφάνιση του πλήκτρου 'restart' και την εξαφάνιση του πλήκτρου 'check'
σε περίπτωση ολοκλήρωσης του παιχνιδιού. */
    if (newGuess.value && !isNaN(newGuess.value)) {
        let state = processGuess(parseInt(newGuess.value));
        if (state == "win" || state == "lost") {
            showElements([restartButton]);
            hideElements([checkButton]);
            preventUserSubmit();
        }
    }
    else {
        message.textContent = "Δώσε αριθμό!";
        message.style.backgroundColor = styles.getPropertyValue("--msg-wrong-color");
        newGuess.value = "";
    }
}

function preventUserSubmit() {
    newGuess.disabled = true;
}

function addGuess(newValue) {
    previousGuesses.push(newValue);
    newGuess.value = "";
}

function previusTries() {
    return `Προηγούμενες προσπάθειες: ${previousGuesses.join(" ")}`;
}

function checkState(newValue) {
    if (!newValue || isNaN(newValue)) {return "NaN";}
    else if (newValue == theGuess && previousGuesses.length <= 10 ) {return "win";}
    else if (newValue != theGuess && previousGuesses.length >= 10) {return "lost"}
    else if (newValue > theGuess) {return "bigger";}
    else {return "smaller";}
}

function getMessage(state) {
    switch (state) {
        case "win":
            return "Μπράβο το βρήκες!";
            break;
        case "lost":
            return "Τέλος παιχνιδιού, έχασες!";
            break;
        case "bigger":
            return "Λάθος, το ξεπέρασες";
            break;
        case "smaller":
            return "Λάθος, είσαι πιο χαμηλά";
            break;
        default:
            return "Δώσε αριθμό!";
            break;
    }
}

function createMessage(state) {
    message.textContent = getMessage(state); 
    lowHigh.textContent = previusTries();
    message.style.backgroundColor = (() => { 
        return state == "win" ? styles.getPropertyValue('--msg-win-color') : styles.getPropertyValue('--msg-wrong-color')})();

}

function hideElements(elements) {
    elements.forEach((element) => {element.style.display = "none";});
}

function restartElements(elements) {
    elements.forEach((element) => {element.textContent = "";});
}

function showElements(elements) {
    elements.forEach((element) => {element.style.display = "unset";});
}

function processGuess(newValue){
 /* 6.  Να ορίσετε συνάρτηση processGuess(newValue) η οποία καλείται από τη συνάρτηση checkGuess,
 περιέχει τη λογική του παιχνιδιού, ελέγχει αν η τιμή του χρήστη είναι σωστή, ή αν το παιχνίδι έχει
 τελειώσει χωρίς ο χρήστης να έχει βρει τον αριθμό, και επιστρέφει αντίστοιχα την τιμή "win", ή "lost",
 δημιουργεί και εμφανίζει τα κατάλληλα μηνύματα, αλλάζοντας το χρώμα του στοιχείου μηνυμάτων.
 Όλα τα μηνύματα του προγράμματος εμανίζονται από την processGuess().
 Σε περίπτωση που το παιχνίδι δεν έχει ακόμα τελειώσει, η συνάρτηση μπορεί είτε να μην επιστρέφει κάποια ιδιαίτερη τιμή,
 είτε να επιστρέφει κάποια τιμή της επιλογής σας */
    addGuess(newValue); 
    state = checkState(newValue);
    createMessage(state);
    return state;
 
}
function restart(){
/* 7. Να ορίσετε συνάρτηση restart η οποία καλείται όταν ο χρήστης πατήσει το πλήκτρο
'restart' και επανεκινεί τη διαδικασία */
    previousGuesses = new Array();
    showElements([newGuess, checkButton]);
    hideElements([restartButton]);
    restartElements([message, lowHigh]);
    newGuess.disabled = false;
    newRandom();
}
